<?php 
class TargetModel extends BaseModel{
	
	protected $table = 'tbl_target';
	protected $pk	 = 'id_target';
	
}