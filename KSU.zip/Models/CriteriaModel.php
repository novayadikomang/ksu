<?php 
class CriteriaModel extends BaseModel{
	
	protected $table = 'criteria';
	protected $pk	 = 'id';
	

}