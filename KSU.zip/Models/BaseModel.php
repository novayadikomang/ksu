<?php 
class BaseModel Extends Crud{
	
	


}