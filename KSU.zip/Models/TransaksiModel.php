<?php 
class TransaksiModel extends BaseModel{
	
	protected $table = 'tbl_trans';
	protected $pk	 = 'id_trans';
	
}