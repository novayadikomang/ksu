<?php 
class Person extends BaseController{

	function index(){
		echo 'test';
	}

}