<?php 
define('DOMAIN','http://localhost:8080');
define('PATH','/koperasi/');
define('BASE_URL',DOMAIN . PATH);
